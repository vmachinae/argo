/*
 *  isValidObject.cpp
 *  TestSuite
 *
 *  Created by Jonathan Wallace on 11/13/11.
 *  Copyright 2011 StreamWIDE. All rights reserved.
 *
 */

#include "isValidObject.h"

