#ifndef RUN_TEST_SUITE2_H
#define RUN_TEST_SUITE2_H

class RunTestSuite2 {
public:
	static void RunTests(void);
};

#endif
